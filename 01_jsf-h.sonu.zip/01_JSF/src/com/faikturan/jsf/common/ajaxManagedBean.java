package com.faikturan.jsf.common;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class ajaxManagedBean {
	String isim = "";

	public String getIsim() {
		return isim;
	}

	public void setIsim(String isim) {
		this.isim = isim;
	}

	public String hosgeldinizsoyle(){
		if (isim.equals("") || isim==null) 
		return "";
		else
		return "Ajax Mesaj�: Ho�geldin " + isim;
	}
}
