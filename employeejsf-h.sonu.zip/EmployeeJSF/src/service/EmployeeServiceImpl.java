package service;

import dao.EmployeeDAOImpl;

public class EmployeeServiceImpl {
	
	private static EmployeeDAOImpl employeeDAOImpl;
	
	public EmployeeServiceImpl() {
		employeeDAOImpl = new EmployeeDAOImpl();
	}

	public static EmployeeDAOImpl getEmployeeDAOImpl() {
		return employeeDAOImpl;
	}

	
}
